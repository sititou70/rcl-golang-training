on thinkpad E13

```
1 goroutine
done: 1.245µs
10 goroutine
done: 5.329µs
100 goroutine
done: 26.347µs
1000 goroutine
done: 192.58µs
10000 goroutine
done: 2.813009ms
100000 goroutine
done: 29.461568ms
1000000 goroutine
done: 358.332049ms
10000000 goroutine
signal: killed
```
